
export { default as RegisterController } from "./auth/RegisterController"