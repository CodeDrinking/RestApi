import dotenv from "dotenv";
dotenv.config();

export const  {
    
    // App_Port,
    DEBUG_MODE
    // DB_URL
    ,JWT_SECRET

}=process.env